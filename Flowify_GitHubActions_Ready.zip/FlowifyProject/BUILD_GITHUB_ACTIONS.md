# Build Flowify APK guna GitHub Actions (tanpa PC)

Langkah ni biar GitHub build APK untuk ko, ko download terus ke phone.

## 1. Buat repo GitHub
- Buka github.com (boleh guna browser phone) -> New repository -> nama `Flowify` -> Create.

## 2. Upload kod
Paling senang dari phone:
- Dalam repo kosong tu, tekan **Add file -> Upload files**.
- Upload SEMUA isi folder `FlowifyProject` (termasuk folder tersembunyi `.github`).
  - Nota: app GitHub mobile / browser kadang tak upload folder `.github` automatik. Kalau jadi, buat file manual:
    **Add file -> Create new file** -> nama: `.github/workflows/build.yml` -> paste isi fail tu.
- Commit ke branch `main`.

## 3. Workflow auto-jalan
- Pergi tab **Actions** dalam repo.
- Workflow "Build Flowify APK" akan start sendiri lepas push (atau tekan **Run workflow** untuk trigger manual).
- Tunggu ~3-6 minit sampai jadi hijau.

## 4. Download APK
- Klik run yang dah siap -> scroll bawah ke bahagian **Artifacts** -> download **Flowify-debug-apk**.
- Ia zip; extract -> dapat `app-debug.apk`.

## 5. Install di phone
- Buka `app-debug.apk` -> benarkan "Install unknown apps" untuk app yang ko guna (Files/Chrome) -> Install.

---

## Nota penting
- Ini **debug APK** (unsigned-debug) — boleh install terus untuk test. Untuk release Play Store kena signing config berasingan.
- **Gradle sync perlu internet** — JitPack akan download NewPipeExtractor.
- Versi yang di-pin: AGP 8.1.4, Kotlin 1.9.0, Gradle 8.4, compileSdk 34. Kalau ko nak naikkan, pastikan compose compiler & Kotlin sepadan.
- App guna icon launcher adaptif (vector) yang ak generate — takde PNG, jadi tak perlu risau resolusi.
