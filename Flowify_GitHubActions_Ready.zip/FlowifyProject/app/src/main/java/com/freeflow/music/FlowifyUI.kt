package com.freeflow.music

import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.launch
import java.time.LocalTime

@Composable
fun rememberMediaController(): MediaController? {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, FlowifyPlaybackService::class.java))
        val future: ListenableFuture<MediaController> = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = try { future.get() } catch (e: Exception) { null }
        }, MoreExecutors.directExecutor())
        onDispose {
            // Elak leak: lepaskan controller & future bila composable dibuang.
            controller?.release()
            MediaController.releaseFuture(future)
        }
    }
    return controller
}

@Composable
fun FlowifyAppStructure(viewModel: HomeViewModel, repository: FlowifyRepository) {
    var currentTab by remember { mutableIntStateOf(0) }
    val controller = rememberMediaController()
    val scope = rememberCoroutineScope()

    val context = LocalContext.current

    // Satu fungsi play dikongsi semua skrin.
    val playSong: (CachedSong) -> Unit = play@{ song ->
        val c = controller
        if (c == null) {
            Toast.makeText(context, "Player belum sedia, cuba lagi sekejap", Toast.LENGTH_SHORT).show()
            return@play
        }
        scope.launch {
            // extractDirectAudioUrl dah jalan atas Dispatchers.IO di dalam.
            val streamUrl = repository.extractDirectAudioUrl(song.videoId)
            if (streamUrl.isEmpty()) {
                Toast.makeText(context, "Tak dapat audio untuk lagu ni", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val mediaItem = MediaItem.Builder()
                .setUri(streamUrl)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .build()
                )
                .build()
            c.setMediaItem(mediaItem)
            c.prepare()
            c.play()
        }
    }

    Scaffold(
        bottomBar = {
            Column {
                MiniPlayerComponent(controller)
                BottomNavigationBarComponent(currentTab) { currentTab = it }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (currentTab) {
                0 -> HomeScreenUI(viewModel, playSong)
                1 -> SearchScreenUI(viewModel, playSong)
                2 -> LibraryScreenUI(viewModel)
                else -> Box(Modifier.fillMaxSize().background(Color.Black))
            }
        }
    }
}

@Composable
fun HomeScreenUI(viewModel: HomeViewModel, onSongClick: (CachedSong) -> Unit) {
    val state by viewModel.uiState.collectAsState()
    val greeting = remember {
        when (LocalTime.now().hour) {
            in 5..11 -> "Good morning"
            in 12..17 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color(0xFF121212)).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 24.dp)) {
                Text(greeting, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("build v4 • play + home fix", fontSize = 11.sp, color = Color(0xFF1DB954))
            }
        }

        when (val s = state) {
            is HomeState.Loading -> item { CircularProgressIndicator(color = Color(0xFF1DB954)) }
            is HomeState.Success -> item {
                HorizontalMusicShelf(title = "Trending on YT Music", songs = s.songs, onSongClick = onSongClick)
            }
            is HomeState.Error -> item {
                Column {
                    Text(s.message, color = Color.Gray, fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))
                    if (s.cachedSongs.isNotEmpty()) {
                        HorizontalMusicShelf(title = "Offline Cache", songs = s.cachedSongs, onSongClick = onSongClick)
                    }
                }
            }
        }
    }
}

@Composable
fun HorizontalMusicShelf(title: String, songs: List<CachedSong>, onSongClick: (CachedSong) -> Unit) {
    Column {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(bottom = 12.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(songs) { song ->
                Column(modifier = Modifier.width(140.dp).clickable { onSongClick(song) }) {
                    AsyncImage(model = song.coverUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(140.dp).clip(RoundedCornerShape(8.dp)))
                    Text(song.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                    Text(song.artist, fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun SearchScreenUI(viewModel: HomeViewModel, onSongClick: (CachedSong) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results by viewModel.searchResults.collectAsState()

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF121212)).padding(16.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; viewModel.search(it) },
            placeholder = { Text("Cari lagu atau artis") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        )
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results) { song ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(model = song.coverUrl, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(4.dp)))
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(song.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayerComponent(controller: MediaController?) {
    controller ?: return

    // Jadikan playback state observable supaya UI recompose bila berubah.
    var isPlaying by remember { mutableStateOf(controller.isPlaying) }
    var currentItem by remember { mutableStateOf(controller.currentMediaItem) }

    DisposableEffect(controller) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { currentItem = mediaItem }
        }
        controller.addListener(listener)
        // Sinkron nilai semasa sebaik daftar.
        isPlaying = controller.isPlaying
        currentItem = controller.currentMediaItem
        onDispose { controller.removeListener(listener) }
    }

    val item = currentItem ?: return

    Row(
        modifier = Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF282828)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(start = 16.dp)) {
            Text(item.mediaMetadata.title?.toString() ?: "Unknown", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(item.mediaMetadata.artist?.toString() ?: "Unknown", color = Color.Gray, fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onClick = { if (isPlaying) controller.pause() else controller.play() }) {
            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
fun BottomNavigationBarComponent(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    val items = listOf("Home", "Search", "Library")
    val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.LibraryMusic)
    NavigationBar(containerColor = Color.Black, modifier = Modifier.height(80.dp)) {
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                icon = { Icon(icons[index], contentDescription = item) },
                label = { Text(item, fontSize = 10.sp) },
                selected = selectedTab == index,
                onClick = { onTabSelected(index) }
            )
        }
    }
}

@Composable
fun LibraryScreenUI(viewModel: HomeViewModel) {
    val state by viewModel.uiState.collectAsState()
    LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)) {
        item { Text("Your Library", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(bottom = 16.dp)) }
        val s = state
        if (s is HomeState.Success) {
            items(s.songs) { song ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(model = song.coverUrl, contentDescription = null, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(4.dp)))
                    Column(modifier = Modifier.padding(start = 16.dp)) {
                        Text(song.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("Playlist • ${song.artist}", color = Color.Gray, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
