package com.freeflow.music

import android.content.Context
import android.util.Log
import androidx.room.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.kiosk.KioskInfo

private const val TAG = "Flowify"

@Entity(tableName = "flowify_cache")
data class CachedSong(
    @PrimaryKey val videoId: String,
    val title: String,
    val artist: String,
    val coverUrl: String,
    val isDownloaded: Boolean = false,
    val cachedAt: Long = System.currentTimeMillis()
)

@Dao
interface SongDao {
    @Query("SELECT * FROM flowify_cache ORDER BY cachedAt DESC")
    fun getAllCachedSongs(): Flow<List<CachedSong>>

    @Query("SELECT * FROM flowify_cache WHERE isDownloaded = 1 ORDER BY cachedAt DESC")
    fun getDownloadedSongs(): Flow<List<CachedSong>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: CachedSong)

    @Delete
    suspend fun deleteSong(song: CachedSong)

    // Eviction: kekalkan hanya N entri terbaru (selain yang di-download).
    @Query(
        "DELETE FROM flowify_cache WHERE isDownloaded = 0 AND videoId NOT IN " +
            "(SELECT videoId FROM flowify_cache ORDER BY cachedAt DESC LIMIT :keep)"
    )
    suspend fun trimCache(keep: Int)
}

@Database(entities = [CachedSong::class], version = 1, exportSchema = false)
abstract class FlowifyDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    companion object {
        @Volatile private var INSTANCE: FlowifyDatabase? = null
        fun getDatabase(context: Context): FlowifyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FlowifyDatabase::class.java,
                    "flowify_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

data class YtMusicRequest(
    val context: YtContext = YtContext(),
    val query: String? = null,
    val browseId: String? = null,
    val videoId: String? = null
)
data class YtContext(val client: YtClient = YtClient())
data class YtClient(
    val hl: String = "en",
    val gl: String = "MY",
    val clientName: String = "WEB_REMIX",
    val clientVersion: String = "1.20240306.01.00"
)

interface YtMusicApi {
    @POST("browse?alt=json")
    suspend fun getHomePage(@Body body: YtMusicRequest): okhttp3.ResponseBody

    @POST("search?alt=json")
    suspend fun searchSong(@Body body: YtMusicRequest): okhttp3.ResponseBody

    @POST("player?alt=json")
    suspend fun getAudioStreamUrl(@Body body: YtMusicRequest): okhttp3.ResponseBody
}

object NetworkClient {
    private val client = OkHttpClient.Builder().addInterceptor { chain ->
        val request = chain.request().newBuilder()
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            .header("Origin", "https://music.youtube.com")
            .build()
        chain.proceed(request)
    }.build()

    val api: YtMusicApi = Retrofit.Builder()
        .baseUrl("https://music.youtube.com/youtubei/v1/")
        .client(client)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(YtMusicApi::class.java)
}

sealed class Resource<T>(val data: T? = null, val message: String? = null) {
    class Success<T>(data: T) : Resource<T>(data)
    class Loading<T>(data: T? = null) : Resource<T>(data)
    class Error<T>(message: String, data: T? = null) : Resource<T>(data, message)
}

class FlowifyRepository(private val api: YtMusicApi, private val songDao: SongDao) {

    /** Single source of truth: UI observe Room terus. */
    fun observeCachedSongs(): Flow<List<CachedSong>> = songDao.getAllCachedSongs()

    /** Refresh dari network, tulis ke Room. Tak emit list — UI dengar dari observeCachedSongs(). */
    suspend fun refreshTrending(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Guna search seed lagu popular sebagai "trending" — lebih relevan untuk app
            // muzik & jauh lebih stabil daripada kiosk Trending (kerap kosong/berubah).
            val service = ServiceList.YouTube
            val handler = service.searchQHFactory.fromQuery("top hits 2024", listOf("music_songs"), "")
            val info = SearchInfo.getInfo(service, handler)
            val songs = info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .mapNotNull { it.toCachedSong() }
            if (songs.isEmpty()) return@withContext Result.failure(Exception("Tiada hasil trending"))
            songs.forEach { songDao.insertSong(it) }
            songDao.trimCache(keep = 200)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "refreshTrending failed", e)
            Result.failure(e)
        }
    }

    suspend fun searchSongs(query: String): List<CachedSong> = withContext(Dispatchers.IO) {
        try {
            // Guna NewPipe search (filter lagu YT Music) — terus berfungsi tanpa API key.
            val service = ServiceList.YouTube
            val handler = service.searchQHFactory.fromQuery(query, listOf("music_songs"), "")
            val info = SearchInfo.getInfo(service, handler)
            info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .mapNotNull { it.toCachedSong() }
        } catch (e: Exception) {
            Log.e(TAG, "searchSongs failed", e)
            emptyList()
        }
    }

    /** Tukar StreamInfoItem NewPipe -> CachedSong app. */
    private fun StreamInfoItem.toCachedSong(): CachedSong? {
        val vid = url.substringAfter("v=", "").substringBefore("&")
        if (vid.isEmpty()) return null
        val songTitle = name.orEmpty()
        if (songTitle.isEmpty()) return null
        val cover = thumbnails.lastOrNull()?.url.orEmpty()
        return CachedSong(
            videoId = vid,
            title = songTitle,
            artist = uploaderName.orEmpty(),
            coverUrl = cover
        )
    }

    /**
     * Guna NewPipeExtractor untuk dapatkan URL audio yang TERUS boleh main.
     * NewPipe handle decipher signature + transform param `n` (yang YouTube
     * sentiasa ubah), jadi kita tak payah parse streamingData manual lagi.
     */
    suspend fun extractDirectAudioUrl(videoId: String): String = withContext(Dispatchers.IO) {
        try {
            val url = "https://www.youtube.com/watch?v=$videoId"
            val info = StreamInfo.getInfo(ServiceList.YouTube, url)
            info.audioStreams
                .filter { !it.content.isNullOrEmpty() }
                .maxByOrNull { it.averageBitrate }
                ?.content ?: run {
                    Log.w(TAG, "Tiada audio stream untuk $videoId")
                    ""
                }
        } catch (e: Exception) {
            Log.e(TAG, "extractDirectAudioUrl (NewPipe) failed for $videoId", e)
            ""
        }
    }

    private fun parseJson(jsonStr: String): List<CachedSong> {
        val list = mutableListOf<CachedSong>()
        try {
            val root = JSONObject(jsonStr)
            val contents = root.getJSONObject("contents").getJSONObject("singleColumnBrowseResultsRenderer")
                .getJSONArray("tabs").getJSONObject(0).getJSONObject("tabRenderer")
                .getJSONObject("content").getJSONObject("sectionListRenderer").getJSONArray("contents")

            // Imbas semua section, bukan index [0] sahaja — lebih tahan bila layout berubah.
            for (s in 0 until contents.length()) {
                val shelf = contents.optJSONObject(s)?.optJSONObject("musicCarouselShelfRenderer")
                    ?.optJSONArray("contents") ?: continue
                for (i in 0 until shelf.length()) {
                    val item = shelf.optJSONObject(i)?.optJSONObject("musicTwoRowItemRenderer") ?: continue
                    val videoId = item.optJSONObject("navigationEndpoint")
                        ?.optJSONObject("watchEndpoint")?.optString("videoId").orEmpty()
                    if (videoId.isEmpty()) continue
                    val title = firstRunText(item.optJSONObject("title"))
                    val artist = firstRunText(item.optJSONObject("subtitle"))
                    val coverUrl = lastThumbnailUrl(item.optJSONObject("thumbnail")
                        ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail"))
                    if (title.isNotEmpty()) list.add(CachedSong(videoId, title, artist, coverUrl))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "parseJson failed", e)
        }
        return list
    }

    private fun parseSearchJson(jsonStr: String): List<CachedSong> {
        val list = mutableListOf<CachedSong>()
        try {
            val root = JSONObject(jsonStr)
            val sections = root.getJSONObject("contents")
                .getJSONObject("tabbedSearchResultsRenderer")
                .getJSONArray("tabs").getJSONObject(0)
                .getJSONObject("tabRenderer").getJSONObject("content")
                .getJSONObject("sectionListRenderer").getJSONArray("contents")
            for (s in 0 until sections.length()) {
                val items = sections.optJSONObject(s)?.optJSONObject("musicShelfRenderer")
                    ?.optJSONArray("contents") ?: continue
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i)
                        ?.optJSONObject("musicResponsiveListItemRenderer") ?: continue
                    val videoId = item.optJSONObject("playlistItemData")?.optString("videoId").orEmpty()
                    if (videoId.isEmpty()) continue
                    val cols = item.optJSONArray("flexColumns") ?: continue
                    val title = flexColumnText(cols, 0)
                    val artist = flexColumnText(cols, 1)
                    val coverUrl = lastThumbnailUrl(item.optJSONObject("thumbnail")
                        ?.optJSONObject("musicThumbnailRenderer")?.optJSONObject("thumbnail"))
                    if (title.isNotEmpty()) list.add(CachedSong(videoId, title, artist, coverUrl))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "parseSearchJson failed", e)
        }
        return list
    }

    private fun firstRunText(node: JSONObject?): String = try {
        node?.getJSONArray("runs")?.getJSONObject(0)?.getString("text").orEmpty()
    } catch (e: Exception) { "" }

    private fun flexColumnText(cols: JSONArray, index: Int): String = try {
        cols.getJSONObject(index)
            .getJSONObject("musicResponsiveListItemFlexColumnRenderer")
            .getJSONObject("text").getJSONArray("runs")
            .getJSONObject(0).getString("text")
    } catch (e: Exception) { "" }

    private fun lastThumbnailUrl(thumb: JSONObject?): String = try {
        val arr = thumb?.getJSONArray("thumbnails")
        if (arr != null && arr.length() > 0) arr.getJSONObject(arr.length() - 1).getString("url") else ""
    } catch (e: Exception) { "" }
}
