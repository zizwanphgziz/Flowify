package com.freeflow.music

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class HomeState {
    object Loading : HomeState()
    data class Success(val songs: List<CachedSong>) : HomeState()
    data class Error(val message: String, val cachedSongs: List<CachedSong>) : HomeState()
}

class HomeViewModel(private val repository: FlowifyRepository) : ViewModel() {

    private val _isRefreshing = MutableStateFlow(true)
    private val _errorMessage = MutableStateFlow<String?>(null)

    // Gabung: Room (source of truth) + status refresh + error.
    val uiState: StateFlow<HomeState> = combine(
        repository.observeCachedSongs(),
        _isRefreshing,
        _errorMessage
    ) { songs, refreshing, error ->
        when {
            refreshing && songs.isEmpty() -> HomeState.Loading
            error != null -> HomeState.Error(error, songs)
            else -> HomeState.Success(songs)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeState.Loading)

    private val _searchResults = MutableStateFlow<List<CachedSong>>(emptyList())
    val searchResults: StateFlow<List<CachedSong>> = _searchResults
    private var searchJob: Job? = null

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _errorMessage.value = null
            val result = repository.refreshTrending()
            if (result.isFailure) {
                _errorMessage.value = "Offline Mode Aktif"
            }
            _isRefreshing.value = false
        }
    }

    fun search(query: String) {
        searchJob?.cancel()
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        searchJob = viewModelScope.launch {
            delay(350) // debounce — elak spam network setiap ketukan
            _searchResults.value = repository.searchSongs(query)
        }
    }
}
