package com.freeflow.music

import android.app.Application
import okhttp3.OkHttpClient
import org.schabi.newpipe.extractor.NewPipe

/**
 * Application class — init NewPipeExtractor sekali sahaja sebelum apa-apa
 * panggilan extractor. Didaftar dalam AndroidManifest (android:name=".FlowifyApp").
 */
class FlowifyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NewPipe.init(NewPipeDownloader(OkHttpClient()))
    }
}
