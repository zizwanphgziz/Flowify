# Kekalkan model yang digunakan oleh Gson/Retrofit (elak strip oleh R8)
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.freeflow.music.** { *; }

-dontwarn okhttp3.**
-dontwarn retrofit2.**
-dontwarn org.jetbrains.annotations.**
